﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Octokit;

namespace githubfile
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
        public async void updatefile()
        {
            var client = new GitHubClient(new ProductHeaderValue("writeanything"));
            client.Credentials = new Credentials("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");
            string username = "IT-core-soft";
            string foldername = "myfirstfolder";
            string filename = "myfirstfile.txt";
            string branch = "main";
            var getfile = await client.Repository.Content.GetAllContentsByRef(username, foldername, filename, branch);
            var updatefiless = await client.Repository.Content.UpdateFile(username, foldername, filename,
                new UpdateFileRequest("update file", "here is new content", getfile.First().Sha));
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            updatefile();
        }
        /*public async void addfile()
        {
            var client = new GitHubClient(new ProductHeaderValue("writeanyvalueanything"));
            client.Credentials = new Credentials("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");
            var result = await client.Repository.Content.CreateFile
                ("IT-core-soft", "myfirstfolder", "myfirstfile.txt", new CreateFileRequest("first commit", "here is my content", "main", true));
        }*/
        /*public async void deletefile()
        {
            var client = new GitHubClient(new ProductHeaderValue("writeanything"));
            client.Credentials = new Credentials("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");
            var existingfile = await client.Repository.Content.GetAllContentsByRef("IT-core-soft", "myfirstfolder", "myfirstfile.txt","main");
            await client.Repository.Content.DeleteFile("IT-core-soft", "myfirstfolder", "myfirstfile.txt", new DeleteFileRequest("Delete file", existingfile.First().Sha));
        }*/
    }
}
